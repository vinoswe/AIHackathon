"""
Python verification harness.

Re-implements usp_LivingExpenseEngine in Python, reading the same Excel
parameter tables that will be loaded into SQL. The point is twofold:

1.  Confirm every SQL lookup in the SP is satisfied by the Excel data —
    if a row is missing, this script raises.

2.  Provide a portable test runner so analysts can sanity-check the SP
    logic on any platform with Python + pandas, without needing a SQL
    Server instance.

Run:
    python3 verify_sql_logic.py
"""
import os
import pandas as pd

DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")

# ============================================================
# Load all 22 parameter tables once
# ============================================================
def load(name):
    return pd.read_excel(os.path.join(DATA_DIR, f"{name}.xlsx"))

P = {
    "RentTable":           load("PARAM_RentTable"),
    "IncomeBandTier":      load("PARAM_IncomeBandTier"),
    "FamilyUnit":          load("PARAM_FamilyUnit"),
    "RentRatio":           load("PARAM_RentRatio"),
    "ElectricityWater":    load("PARAM_ElectricityWater"),
    "EmirateUtilFactor":   load("PARAM_EmirateUtilFactor"),
    "Telecom":             load("PARAM_Telecom"),
    "DewaFee":             load("PARAM_DewaFee"),
    "EducationBase":       load("PARAM_EducationBase"),
    "FoodPercent":         load("PARAM_FoodPercent"),
    "TransportPercent":    load("PARAM_TransportPercent"),
    "HealthcarePercent":   load("PARAM_HealthcarePercent"),
    "DomesticPercent":     load("PARAM_DomesticPercent"),
    "FamilySupportPercent":load("PARAM_FamilySupportPercent"),
    "LifestylePercent":    load("PARAM_LifestylePercent"),
    "FloorCeiling":        load("PARAM_FloorCeiling"),
    "Insurance":           load("PARAM_Insurance"),
    "HousingFactor":       load("PARAM_HousingFactor"),
    "RegionMultiplier":    load("PARAM_RegionMultiplier"),
    "EducationMultiplier": load("PARAM_EducationMultiplier"),
    "TierTelecomMult":     load("PARAM_TierTelecomMult"),
    "Scalars":             load("PARAM_Scalars"),
}


def scalar(name):
    """SELECT ScalarValue FROM PARAM_Scalars WHERE ParameterName = name"""
    df = P["Scalars"]
    row = df[df["ParameterName"] == name]
    if row.empty:
        raise KeyError(f"Scalar {name!r} not in PARAM_Scalars")
    return float(row.iloc[0]["ScalarValue"])


def lookup_scalar_from(df, key_col, key_val, value_col):
    sub = df[df[key_col] == key_val]
    if sub.empty:
        raise KeyError(f"{key_val!r} not found in {key_col}")
    return sub.iloc[0][value_col]


def lookup_2key(df, k1col, k1, k2col, k2, value_col):
    sub = df[(df[k1col] == k1) & (df[k2col] == k2)]
    if sub.empty:
        raise KeyError(f"({k1}, {k2}) not found in {k1col}/{k2col}")
    return sub.iloc[0][value_col]


def compute(*, salary, family, emirate, housing, income_band,
            nationality, region, kids_uae=0, dep_abroad=0, spouse_income=0):
    """Faithful Python mirror of dbo.usp_LivingExpenseEngine logic."""

    # Step 0 — scalars
    buffer_pct        = scalar("BufferPct")
    cal_essential     = scalar("CalEssential")
    cal_discretionary = scalar("CalDiscretionary")
    spouse_inclusion  = scalar("SpouseInclusion")
    abs_rent_floor    = scalar("AbsRentFloor")
    zero_fallback     = scalar("ZeroSalaryFallback")

    # Step 1 — HH income & primary-for-famsup
    if salary > 0:
        hh = salary + spouse_income * spouse_inclusion
        primary_famsup = salary
    else:
        hh = zero_fallback + spouse_income * spouse_inclusion
        primary_famsup = zero_fallback

    # Step 2 — lookups
    tier            = lookup_scalar_from(P["IncomeBandTier"],    "IncomeBand", income_band, "Tier")
    unit_type       = lookup_scalar_from(P["FamilyUnit"],        "Family",     family,      "UnitType")
    telecom_tier_mul= lookup_scalar_from(P["TierTelecomMult"],   "Tier",       tier,        "Multiplier")
    housing_factor  = lookup_scalar_from(P["HousingFactor"],     "HousingType",housing,     "Factor")
    region_row      = P["RegionMultiplier"][P["RegionMultiplier"]["Region"] == region].iloc[0]
    food_mult       = float(region_row["FoodMult"])
    famsup_mult     = float(region_row["FamSupMult"])
    lifestyle_mult  = float(region_row["LifestyleMult"])
    domestic_mult   = float(region_row["DomesticMult"])

    # Step 3 — property type
    if (nationality == "UAE National" and family in ("Couple+1", "Couple+2", "Couple+3+")) \
       or family == "Couple+3+":
        property_type = "Villa"
    else:
        property_type = "Apartment"

    # Step 4 — RENT
    rent_ratio = lookup_2key(P["RentRatio"], "IncomeBand", income_band, "Family", family, "Ratio")
    premium_ceil = lookup_2key(P["RentTable"], "Emirate", emirate, "UnitType", unit_type, "PremiumAmt")
    raw_rent = hh * float(rent_ratio) * cal_essential
    rent = max(raw_rent, abs_rent_floor)
    rent = min(rent, float(premium_ceil))
    rent = rent * float(housing_factor)

    # Step 5 — FOOD
    food_pct = lookup_2key(P["FoodPercent"], "Family", family, "IncomeBand", income_band, "Pct")
    fc = P["FloorCeiling"][(P["FloorCeiling"]["Category"] == "Food") &
                           (P["FloorCeiling"]["Family"] == family)].iloc[0]
    food_floor, food_ceil = float(fc["FloorAmt"]), float(fc["CeilAmt"])
    raw_food = hh * float(food_pct) * food_mult * cal_essential
    food = max(raw_food, food_floor)
    food = min(food, food_ceil)

    # Step 6 — TRANSPORT
    trn_pct = lookup_2key(P["TransportPercent"], "Family", family, "IncomeBand", income_band, "Pct")
    fc = P["FloorCeiling"][(P["FloorCeiling"]["Category"] == "Transport") &
                           (P["FloorCeiling"]["Family"] == family)].iloc[0]
    trn_floor, trn_ceil = float(fc["FloorAmt"]), float(fc["CeilAmt"])
    raw_trn = hh * float(trn_pct) * cal_essential
    transport = max(raw_trn, trn_floor)
    transport = min(transport, trn_ceil)

    # Step 7 — UTILITIES
    ew_row = P["ElectricityWater"][P["ElectricityWater"]["Family"] == family].iloc[0]
    elec_water = float(ew_row["VillaAmt"] if property_type == "Villa" else ew_row["ApartmentAmt"])
    emirate_factor = float(lookup_scalar_from(P["EmirateUtilFactor"], "Emirate", emirate, "Factor"))
    telecom_base   = float(lookup_scalar_from(P["Telecom"],            "Family",  family, "BaseAmt"))
    dewa_fee       = float(lookup_scalar_from(P["DewaFee"],            "PropertyType", property_type, "FeePct"))
    utilities = elec_water * emirate_factor \
              + telecom_base * float(telecom_tier_mul) \
              + rent * dewa_fee

    # Step 8 — EDUCATION
    if kids_uae > 0:
        edu_base = float(lookup_2key(P["EducationBase"], "Emirate", emirate, "IncomeBand", income_band, "AnnualAED"))
        edu_mult = float(lookup_2key(P["EducationMultiplier"], "Region", region, "IncomeBand", income_band, "Multiplier"))
        education = (edu_base * edu_mult / 12.0) * kids_uae
    else:
        education = 0.0

    # Step 9 — HEALTHCARE
    h_pct = lookup_2key(P["HealthcarePercent"], "Family", family, "IncomeBand", income_band, "Pct")
    fc = P["FloorCeiling"][(P["FloorCeiling"]["Category"] == "Healthcare") &
                           (P["FloorCeiling"]["Family"] == family)].iloc[0]
    h_floor, h_ceil = float(fc["FloorAmt"]), float(fc["CeilAmt"])
    raw_h = hh * float(h_pct) * cal_essential
    healthcare = max(raw_h, h_floor)
    healthcare = min(healthcare, h_ceil)

    # Step 10 — ESSENTIAL SUBTOTAL
    essential = rent + food + transport + utilities + education + healthcare

    # Step 11 — INSURANCE
    insurance_base = float(lookup_scalar_from(P["Insurance"], "IncomeBand", income_band, "BaseAmt"))
    insurance = insurance_base * cal_discretionary

    # Step 12 — FAMILY SUPPORT
    fs_pct = lookup_2key(P["FamilySupportPercent"], "Family", family, "IncomeBand", income_band, "Pct")
    fc = P["FloorCeiling"][(P["FloorCeiling"]["Category"] == "FamilySupport") &
                           (P["FloorCeiling"]["Family"] == family)].iloc[0]
    fs_floor, fs_ceil = float(fc["FloorAmt"]), float(fc["CeilAmt"])
    raw_fs = primary_famsup * float(fs_pct) * famsup_mult * cal_discretionary
    fs_bounded = max(raw_fs, fs_floor)
    fs_bounded = min(fs_bounded, fs_ceil)
    fs_overlay = fs_bounded * (1 + 0.5 * dep_abroad)
    family_support = min(fs_overlay, fs_ceil * 1.5)

    # Step 13 — LIFESTYLE
    ls_pct = lookup_2key(P["LifestylePercent"], "Family", family, "IncomeBand", income_band, "Pct")
    fc = P["FloorCeiling"][(P["FloorCeiling"]["Category"] == "Lifestyle") &
                           (P["FloorCeiling"]["Family"] == family)].iloc[0]
    ls_floor, ls_ceil = float(fc["FloorAmt"]), float(fc["CeilAmt"])
    raw_ls = hh * float(ls_pct) * lifestyle_mult * cal_discretionary
    lifestyle = max(raw_ls, ls_floor)
    lifestyle = min(lifestyle, ls_ceil)

    # Step 14 — DOMESTIC
    d_pct = lookup_2key(P["DomesticPercent"], "Family", family, "IncomeBand", income_band, "Pct")
    fc = P["FloorCeiling"][(P["FloorCeiling"]["Category"] == "Domestic") &
                           (P["FloorCeiling"]["Family"] == family)].iloc[0]
    d_floor, d_ceil = float(fc["FloorAmt"]), float(fc["CeilAmt"])
    raw_d = hh * float(d_pct) * domestic_mult * cal_discretionary
    domestic = max(raw_d, d_floor)
    domestic = min(domestic, d_ceil)

    # Step 15 — DISCRETIONARY SUBTOTAL
    discretionary = insurance + family_support + lifestyle + domestic

    # Step 16 — TOTAL
    total = (essential + discretionary) * (1 + buffer_pct)

    return {
        "EssentialSubtotal":        round(essential, 2),
        "DiscretionarySubtotal":    round(discretionary, 2),
        "TotalMonthlyExpenseFloor": round(total, 2),
    }


# ============================================================
# Test cases — same as 03_test_cases.sql
# ============================================================
TEST_CASES = [
    ("T1 — Junior expat Single Sharjah Western",
     dict(salary=12500, family="Single", emirate="Sharjah-Ajman", housing="Rented",
          income_band="10K-15K", nationality="Expat", region="Western")),
    ("T2 — Mid-career expat Couple Dubai Western",
     dict(salary=40000, family="Couple", emirate="Dubai", housing="Rented",
          income_band="30K-50K", nationality="Expat", region="Western")),
    ("T3 — Indian Couple+2 Dubai South Asian +2 kids",
     dict(salary=115000, family="Couple+2", emirate="Dubai", housing="Rented",
          income_band="80K-150K", nationality="Expat", region="South Asian", kids_uae=2)),
    ("T4 — UAE National Couple+2 AD Owned-free +2 kids",
     dict(salary=115000, family="Couple+2", emirate="Abu Dhabi", housing="Owned-free",
          income_band="80K-150K", nationality="UAE National", region="UAE National", kids_uae=2)),
    ("T5 — Senior expat exec Dubai 200K +2 kids +2 dep abroad",
     dict(salary=200000, family="Couple+3+", emirate="Dubai", housing="Rented",
          income_band="150K+", nationality="Expat", region="Western", kids_uae=2, dep_abroad=2)),
    ("T6 — Expat couple AD Employer housing",
     dict(salary=40000, family="Couple", emirate="Abu Dhabi", housing="Employer",
          income_band="30K-50K", nationality="Expat", region="Western")),
    ("T7 — Filipino Single Northern 4,500 +2 dep abroad",
     dict(salary=4500, family="Single", emirate="Northern", housing="Rented",
          income_band="<10K", nationality="Expat", region="Filipino", dep_abroad=2)),
    ("T8 — Indian Couple+1 Dubai +1 kid +1 dep, spouse income",
     dict(salary=25000, family="Couple+1", emirate="Dubai", housing="Rented",
          income_band="20K-30K", nationality="Expat", region="South Asian",
          kids_uae=1, dep_abroad=1, spouse_income=15000)),
]


def main():
    print(f"{'Test':<55} {'Essential':>12} {'Discr.':>10} {'Total':>12}")
    print("-" * 92)
    for label, kwargs in TEST_CASES:
        result = compute(**kwargs)
        print(f"{label:<55} "
              f"{result['EssentialSubtotal']:>12,.2f} "
              f"{result['DiscretionarySubtotal']:>10,.2f} "
              f"{result['TotalMonthlyExpenseFloor']:>12,.2f}")


if __name__ == "__main__":
    main()
