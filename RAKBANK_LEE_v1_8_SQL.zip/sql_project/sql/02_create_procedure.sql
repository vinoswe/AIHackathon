/* =================================================================
   RAKBANK Living Expense Engine v1.8 — Stored Procedure
   ----------------------------------------------------------------
   usp_LivingExpenseEngine
   ----------------------------------------------------------------
   Computes monthly living expense estimate from customer profile.

   RETURNS A SINGLE ROW WITH EXACTLY THREE COLUMNS:
       EssentialSubtotal            (DECIMAL(18,2))
       DiscretionarySubtotal        (DECIMAL(18,2))
       TotalMonthlyExpenseFloor     (DECIMAL(18,2))

   No other output is produced.

   Dialect: T-SQL (Microsoft SQL Server 2016+).
   ================================================================= */

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

IF OBJECT_ID('dbo.usp_LivingExpenseEngine', 'P') IS NOT NULL
    DROP PROCEDURE dbo.usp_LivingExpenseEngine;
GO

CREATE PROCEDURE dbo.usp_LivingExpenseEngine
    @Salary          DECIMAL(18,2),
    @Family          VARCHAR(20),
    @Emirate         VARCHAR(20),
    @Housing         VARCHAR(20),
    @IncomeBand      VARCHAR(20),
    @Nationality     VARCHAR(20),
    @Region          VARCHAR(50),
    @KidsUAE         INT            = 0,
    @DepAbroad       INT            = 0,
    @SpouseIncome    DECIMAL(18,2)  = 0
AS
BEGIN
    SET NOCOUNT ON;

    /* ------------------------------------------------------------
       0. Load scalar parameters
       ------------------------------------------------------------ */
    DECLARE @BufferPct           DECIMAL(18,4);
    DECLARE @CalEssential        DECIMAL(18,4);
    DECLARE @CalDiscretionary    DECIMAL(18,4);
    DECLARE @SpouseInclusion     DECIMAL(18,4);
    DECLARE @AbsRentFloor        DECIMAL(18,2);
    DECLARE @ZeroSalaryFallback  DECIMAL(18,2);

    SELECT @BufferPct          = ScalarValue FROM dbo.PARAM_Scalars WHERE ParameterName = 'BufferPct';
    SELECT @CalEssential       = ScalarValue FROM dbo.PARAM_Scalars WHERE ParameterName = 'CalEssential';
    SELECT @CalDiscretionary   = ScalarValue FROM dbo.PARAM_Scalars WHERE ParameterName = 'CalDiscretionary';
    SELECT @SpouseInclusion    = ScalarValue FROM dbo.PARAM_Scalars WHERE ParameterName = 'SpouseInclusion';
    SELECT @AbsRentFloor       = ScalarValue FROM dbo.PARAM_Scalars WHERE ParameterName = 'AbsRentFloor';
    SELECT @ZeroSalaryFallback = ScalarValue FROM dbo.PARAM_Scalars WHERE ParameterName = 'ZeroSalaryFallback';

    /* ------------------------------------------------------------
       1. Derive household income & primary-for-famsup
       Household income: HH = salary + 0.5 * spouse (zero-salary
       fallback uses 7,000 + 0.5 * spouse).
       Family-support income: primary salary alone (with fallback).
       ------------------------------------------------------------ */
    DECLARE @HH_Income          DECIMAL(18,2);
    DECLARE @PrimaryForFamSup   DECIMAL(18,2);

    IF @Salary > 0
    BEGIN
        SET @HH_Income        = @Salary + @SpouseIncome * @SpouseInclusion;
        SET @PrimaryForFamSup = @Salary;
    END
    ELSE
    BEGIN
        SET @HH_Income        = @ZeroSalaryFallback + @SpouseIncome * @SpouseInclusion;
        SET @PrimaryForFamSup = @ZeroSalaryFallback;
    END

    /* ------------------------------------------------------------
       2. Look up tier, unit type, telecom-tier multiplier,
       housing factor, and region multipliers.
       ------------------------------------------------------------ */
    DECLARE @Tier             VARCHAR(20);
    DECLARE @UnitType         VARCHAR(20);
    DECLARE @TelecomTierMult  DECIMAL(18,4);
    DECLARE @HousingFactor    DECIMAL(18,4);

    SELECT @Tier            = Tier        FROM dbo.PARAM_IncomeBandTier  WHERE IncomeBand  = @IncomeBand;
    SELECT @UnitType        = UnitType    FROM dbo.PARAM_FamilyUnit      WHERE Family      = @Family;
    SELECT @TelecomTierMult = Multiplier  FROM dbo.PARAM_TierTelecomMult WHERE Tier        = @Tier;
    SELECT @HousingFactor   = Factor      FROM dbo.PARAM_HousingFactor   WHERE HousingType = @Housing;

    DECLARE @FoodMult       DECIMAL(18,4);
    DECLARE @FamSupMult     DECIMAL(18,4);
    DECLARE @LifestyleMult  DECIMAL(18,4);
    DECLARE @DomesticMult   DECIMAL(18,4);

    SELECT @FoodMult       = FoodMult,
           @FamSupMult     = FamSupMult,
           @LifestyleMult  = LifestyleMult,
           @DomesticMult   = DomesticMult
    FROM dbo.PARAM_RegionMultiplier
    WHERE Region = @Region;

    /* ------------------------------------------------------------
       3. Property-type rule:
       Villa if UAE National with kids OR family is Couple+3+;
       else Apartment.
       ------------------------------------------------------------ */
    DECLARE @PropertyType VARCHAR(20);
    IF (@Nationality = 'UAE National' AND @Family IN ('Couple+1','Couple+2','Couple+3+'))
        OR @Family = 'Couple+3+'
        SET @PropertyType = 'Villa';
    ELSE
        SET @PropertyType = 'Apartment';

    /* ------------------------------------------------------------
       4. RENT
       Raw = HH * RentRatio * CalEssential
       Bounded by [AbsRentFloor, PremiumCeiling], then * HousingFactor
       ------------------------------------------------------------ */
    DECLARE @RentRatio        DECIMAL(18,4);
    DECLARE @PremiumCeiling   DECIMAL(18,2);
    DECLARE @RawRent          DECIMAL(18,2);
    DECLARE @Rent             DECIMAL(18,2);

    SELECT @RentRatio      = Ratio       FROM dbo.PARAM_RentRatio
        WHERE IncomeBand = @IncomeBand AND Family = @Family;
    SELECT @PremiumCeiling = PremiumAmt  FROM dbo.PARAM_RentTable
        WHERE Emirate = @Emirate AND UnitType = @UnitType;

    SET @RawRent = @HH_Income * @RentRatio * @CalEssential;
    SET @Rent = CASE WHEN @RawRent < @AbsRentFloor THEN @AbsRentFloor ELSE @RawRent END;
    SET @Rent = CASE WHEN @Rent  > @PremiumCeiling THEN @PremiumCeiling ELSE @Rent END;
    SET @Rent = @Rent * @HousingFactor;

    /* ------------------------------------------------------------
       5. FOOD = HH * FoodPct * FoodMult * CalEssential,
          bounded by floor/ceiling on category Food.
       ------------------------------------------------------------ */
    DECLARE @FoodPct      DECIMAL(18,4);
    DECLARE @FoodFloor    DECIMAL(18,2);
    DECLARE @FoodCeil     DECIMAL(18,2);
    DECLARE @RawFood      DECIMAL(18,2);
    DECLARE @Food         DECIMAL(18,2);

    SELECT @FoodPct   = Pct      FROM dbo.PARAM_FoodPercent
        WHERE Family = @Family AND IncomeBand = @IncomeBand;
    SELECT @FoodFloor = FloorAmt, @FoodCeil = CeilAmt FROM dbo.PARAM_FloorCeiling
        WHERE Category = 'Food' AND Family = @Family;

    SET @RawFood = @HH_Income * @FoodPct * @FoodMult * @CalEssential;
    SET @Food = CASE WHEN @RawFood < @FoodFloor THEN @FoodFloor ELSE @RawFood END;
    SET @Food = CASE WHEN @Food    > @FoodCeil  THEN @FoodCeil  ELSE @Food    END;

    /* ------------------------------------------------------------
       6. TRANSPORT (no region multiplier).
       ------------------------------------------------------------ */
    DECLARE @TransportPct    DECIMAL(18,4);
    DECLARE @TransportFloor  DECIMAL(18,2);
    DECLARE @TransportCeil   DECIMAL(18,2);
    DECLARE @RawTransport    DECIMAL(18,2);
    DECLARE @Transport       DECIMAL(18,2);

    SELECT @TransportPct   = Pct      FROM dbo.PARAM_TransportPercent
        WHERE Family = @Family AND IncomeBand = @IncomeBand;
    SELECT @TransportFloor = FloorAmt, @TransportCeil = CeilAmt FROM dbo.PARAM_FloorCeiling
        WHERE Category = 'Transport' AND Family = @Family;

    SET @RawTransport = @HH_Income * @TransportPct * @CalEssential;
    SET @Transport = CASE WHEN @RawTransport < @TransportFloor THEN @TransportFloor ELSE @RawTransport END;
    SET @Transport = CASE WHEN @Transport    > @TransportCeil  THEN @TransportCeil  ELSE @Transport    END;

    /* ------------------------------------------------------------
       7. UTILITIES
       = elec/water (by family × property × emirate factor)
       + telecom (by family × tier mult)
       + rent × DEWA fee %
       ------------------------------------------------------------ */
    DECLARE @ElecWater     DECIMAL(18,2);
    DECLARE @EmirateFactor DECIMAL(18,4);
    DECLARE @TelecomBase   DECIMAL(18,2);
    DECLARE @DewaFeePct    DECIMAL(18,4);
    DECLARE @Utilities     DECIMAL(18,2);

    IF @PropertyType = 'Villa'
        SELECT @ElecWater = VillaAmt     FROM dbo.PARAM_ElectricityWater WHERE Family = @Family;
    ELSE
        SELECT @ElecWater = ApartmentAmt FROM dbo.PARAM_ElectricityWater WHERE Family = @Family;

    SELECT @EmirateFactor = Factor   FROM dbo.PARAM_EmirateUtilFactor WHERE Emirate      = @Emirate;
    SELECT @TelecomBase   = BaseAmt  FROM dbo.PARAM_Telecom           WHERE Family       = @Family;
    SELECT @DewaFeePct    = FeePct   FROM dbo.PARAM_DewaFee            WHERE PropertyType = @PropertyType;

    SET @Utilities = (@ElecWater  * @EmirateFactor)
                   + (@TelecomBase * @TelecomTierMult)
                   + (@Rent        * @DewaFeePct);

    /* ------------------------------------------------------------
       8. EDUCATION
       If KidsUAE > 0:
           edu = (AnnualAED * EduMult / 12) * KidsUAE
       Else: 0.
       No floor/ceiling (counted in raw form).
       ------------------------------------------------------------ */
    DECLARE @EduBaseAnnual DECIMAL(18,2);
    DECLARE @EduMult       DECIMAL(18,4);
    DECLARE @Education     DECIMAL(18,2);

    IF @KidsUAE > 0
    BEGIN
        SELECT @EduBaseAnnual = AnnualAED  FROM dbo.PARAM_EducationBase
            WHERE Emirate = @Emirate AND IncomeBand = @IncomeBand;
        SELECT @EduMult       = Multiplier FROM dbo.PARAM_EducationMultiplier
            WHERE Region = @Region  AND IncomeBand = @IncomeBand;
        SET @Education = (@EduBaseAnnual * @EduMult / 12.0) * @KidsUAE;
    END
    ELSE
    BEGIN
        SET @Education = 0;
    END

    /* ------------------------------------------------------------
       9. HEALTHCARE  (no region multiplier).
       ------------------------------------------------------------ */
    DECLARE @HealthPct    DECIMAL(18,4);
    DECLARE @HealthFloor  DECIMAL(18,2);
    DECLARE @HealthCeil   DECIMAL(18,2);
    DECLARE @RawHealth    DECIMAL(18,2);
    DECLARE @Healthcare   DECIMAL(18,2);

    SELECT @HealthPct   = Pct      FROM dbo.PARAM_HealthcarePercent
        WHERE Family = @Family AND IncomeBand = @IncomeBand;
    SELECT @HealthFloor = FloorAmt, @HealthCeil = CeilAmt FROM dbo.PARAM_FloorCeiling
        WHERE Category = 'Healthcare' AND Family = @Family;

    SET @RawHealth = @HH_Income * @HealthPct * @CalEssential;
    SET @Healthcare = CASE WHEN @RawHealth  < @HealthFloor THEN @HealthFloor ELSE @RawHealth  END;
    SET @Healthcare = CASE WHEN @Healthcare > @HealthCeil  THEN @HealthCeil  ELSE @Healthcare END;

    /* ------------------------------------------------------------
       10. ESSENTIAL SUBTOTAL
       ------------------------------------------------------------ */
    DECLARE @EssentialSubtotal DECIMAL(18,2);
    SET @EssentialSubtotal = @Rent + @Food + @Transport + @Utilities + @Education + @Healthcare;

    /* ------------------------------------------------------------
       11. INSURANCE = BaseAmt (by band) * CalDiscretionary
       ------------------------------------------------------------ */
    DECLARE @InsuranceBase DECIMAL(18,2);
    DECLARE @Insurance     DECIMAL(18,2);
    SELECT @InsuranceBase = BaseAmt FROM dbo.PARAM_Insurance WHERE IncomeBand = @IncomeBand;
    SET @Insurance = @InsuranceBase * @CalDiscretionary;

    /* ------------------------------------------------------------
       12. FAMILY SUPPORT
       Raw   = PrimarySalary * FamSupPct * FamSupMult * CalDiscretionary
       Floor/ceil applied on the bounded amount.
       Overlay = bounded * (1 + 0.5 * DepAbroad).
       Final  = MIN(overlay, 1.5 * ceiling).
       ------------------------------------------------------------ */
    DECLARE @FamSupPct      DECIMAL(18,4);
    DECLARE @FamSupFloor    DECIMAL(18,2);
    DECLARE @FamSupCeil     DECIMAL(18,2);
    DECLARE @RawFamSup      DECIMAL(18,2);
    DECLARE @FamSupBounded  DECIMAL(18,2);
    DECLARE @FamSupOverlay  DECIMAL(18,2);
    DECLARE @FamilySupport  DECIMAL(18,2);
    DECLARE @FamSupHardCap  DECIMAL(18,2);

    SELECT @FamSupPct = Pct FROM dbo.PARAM_FamilySupportPercent
        WHERE Family = @Family AND IncomeBand = @IncomeBand;
    SELECT @FamSupFloor = FloorAmt, @FamSupCeil = CeilAmt FROM dbo.PARAM_FloorCeiling
        WHERE Category = 'FamilySupport' AND Family = @Family;

    SET @RawFamSup     = @PrimaryForFamSup * @FamSupPct * @FamSupMult * @CalDiscretionary;
    SET @FamSupBounded = CASE WHEN @RawFamSup     < @FamSupFloor THEN @FamSupFloor ELSE @RawFamSup     END;
    SET @FamSupBounded = CASE WHEN @FamSupBounded > @FamSupCeil  THEN @FamSupCeil  ELSE @FamSupBounded END;
    SET @FamSupOverlay = @FamSupBounded * (1 + 0.5 * @DepAbroad);
    SET @FamSupHardCap = @FamSupCeil * 1.5;
    SET @FamilySupport = CASE WHEN @FamSupOverlay > @FamSupHardCap THEN @FamSupHardCap ELSE @FamSupOverlay END;

    /* ------------------------------------------------------------
       13. LIFESTYLE
       ------------------------------------------------------------ */
    DECLARE @LifestylePct    DECIMAL(18,4);
    DECLARE @LifestyleFloor  DECIMAL(18,2);
    DECLARE @LifestyleCeil   DECIMAL(18,2);
    DECLARE @RawLifestyle    DECIMAL(18,2);
    DECLARE @Lifestyle       DECIMAL(18,2);

    SELECT @LifestylePct = Pct FROM dbo.PARAM_LifestylePercent
        WHERE Family = @Family AND IncomeBand = @IncomeBand;
    SELECT @LifestyleFloor = FloorAmt, @LifestyleCeil = CeilAmt FROM dbo.PARAM_FloorCeiling
        WHERE Category = 'Lifestyle' AND Family = @Family;

    SET @RawLifestyle = @HH_Income * @LifestylePct * @LifestyleMult * @CalDiscretionary;
    SET @Lifestyle = CASE WHEN @RawLifestyle < @LifestyleFloor THEN @LifestyleFloor ELSE @RawLifestyle END;
    SET @Lifestyle = CASE WHEN @Lifestyle    > @LifestyleCeil  THEN @LifestyleCeil  ELSE @Lifestyle    END;

    /* ------------------------------------------------------------
       14. DOMESTIC
       ------------------------------------------------------------ */
    DECLARE @DomesticPct    DECIMAL(18,4);
    DECLARE @DomesticFloor  DECIMAL(18,2);
    DECLARE @DomesticCeil   DECIMAL(18,2);
    DECLARE @RawDomestic    DECIMAL(18,2);
    DECLARE @Domestic       DECIMAL(18,2);

    SELECT @DomesticPct = Pct FROM dbo.PARAM_DomesticPercent
        WHERE Family = @Family AND IncomeBand = @IncomeBand;
    SELECT @DomesticFloor = FloorAmt, @DomesticCeil = CeilAmt FROM dbo.PARAM_FloorCeiling
        WHERE Category = 'Domestic' AND Family = @Family;

    SET @RawDomestic = @HH_Income * @DomesticPct * @DomesticMult * @CalDiscretionary;
    SET @Domestic = CASE WHEN @RawDomestic < @DomesticFloor THEN @DomesticFloor ELSE @RawDomestic END;
    SET @Domestic = CASE WHEN @Domestic    > @DomesticCeil  THEN @DomesticCeil  ELSE @Domestic    END;

    /* ------------------------------------------------------------
       15. DISCRETIONARY SUBTOTAL
       ------------------------------------------------------------ */
    DECLARE @DiscretionarySubtotal DECIMAL(18,2);
    SET @DiscretionarySubtotal = @Insurance + @FamilySupport + @Lifestyle + @Domestic;

    /* ------------------------------------------------------------
       16. TOTAL MONTHLY EXPENSE FLOOR
       = (Essential + Discretionary) * (1 + BufferPct)
       ------------------------------------------------------------ */
    DECLARE @TotalMonthlyExpenseFloor DECIMAL(18,2);
    SET @TotalMonthlyExpenseFloor = (@EssentialSubtotal + @DiscretionarySubtotal) * (1 + @BufferPct);

    /* ------------------------------------------------------------
       17. RETURN — exactly three columns, no others.
       ------------------------------------------------------------ */
    SELECT
        @EssentialSubtotal          AS EssentialSubtotal,
        @DiscretionarySubtotal      AS DiscretionarySubtotal,
        @TotalMonthlyExpenseFloor   AS TotalMonthlyExpenseFloor;
END
GO

/* =================================================================
   End of procedure.
   ================================================================= */
