/* =================================================================
   RAKBANK Living Expense Engine v1.8 — Test Cases
   ----------------------------------------------------------------
   Smoke-tests the stored procedure with eight canonical customer
   profiles. Expected outputs are documented next to each call.

   Run after 01_create_tables.sql, after loading all 22 Excel files,
   and after 02_create_procedure.sql.
   ================================================================= */

SET NOCOUNT ON;
GO

PRINT '======================================================================';
PRINT 'Test 1: P1 — Junior expat, single, Sharjah, Rented, Western, 12,500';
PRINT 'Expected EssentialSubtotal ~ 4,322   Discretionary ~ 517   Total ~ 5,081';
PRINT '======================================================================';
EXEC dbo.usp_LivingExpenseEngine
    @Salary        = 12500,
    @Family        = 'Single',
    @Emirate       = 'Sharjah-Ajman',
    @Housing       = 'Rented',
    @IncomeBand    = '10K-15K',
    @Nationality   = 'Expat',
    @Region        = 'Western',
    @KidsUAE       = 0,
    @DepAbroad     = 0,
    @SpouseIncome  = 0;
GO

PRINT '';
PRINT '======================================================================';
PRINT 'Test 2: P2 — Mid-career expat couple, Dubai, Rented, Western, 40,000';
PRINT 'Expected EssentialSubtotal ~ 12,593  Discretionary ~ 3,245  Total ~ 16,629';
PRINT '======================================================================';
EXEC dbo.usp_LivingExpenseEngine
    @Salary        = 40000,
    @Family        = 'Couple',
    @Emirate       = 'Dubai',
    @Housing       = 'Rented',
    @IncomeBand    = '30K-50K',
    @Nationality   = 'Expat',
    @Region        = 'Western',
    @KidsUAE       = 0,
    @DepAbroad     = 0,
    @SpouseIncome  = 0;
GO

PRINT '';
PRINT '======================================================================';
PRINT 'Test 3: P3 — Indian expat family of 4, Dubai, Rented, 115,000 + 2 kids';
PRINT 'Expected EssentialSubtotal ~ 52,073  Discretionary ~ 14,639  Total ~ 70,048';
PRINT '======================================================================';
EXEC dbo.usp_LivingExpenseEngine
    @Salary        = 115000,
    @Family        = 'Couple+2',
    @Emirate       = 'Dubai',
    @Housing       = 'Rented',
    @IncomeBand    = '80K-150K',
    @Nationality   = 'Expat',
    @Region        = 'South Asian',
    @KidsUAE       = 2,
    @DepAbroad     = 0,
    @SpouseIncome  = 0;
GO

PRINT '';
PRINT '======================================================================';
PRINT 'Test 4: P4 — UAE National family, AD, Owned-free, 115,000 + 2 kids';
PRINT 'Expected EssentialSubtotal ~ 27,520  Discretionary ~ 12,015  Total ~ 41,511';
PRINT '======================================================================';
EXEC dbo.usp_LivingExpenseEngine
    @Salary        = 115000,
    @Family        = 'Couple+2',
    @Emirate       = 'Abu Dhabi',
    @Housing       = 'Owned-free',
    @IncomeBand    = '80K-150K',
    @Nationality   = 'UAE National',
    @Region        = 'UAE National',
    @KidsUAE       = 2,
    @DepAbroad     = 0,
    @SpouseIncome  = 0;
GO

PRINT '';
PRINT '======================================================================';
PRINT 'Test 5: P6 — Senior expat exec, Dubai, Rented, 200,000, large family';
PRINT 'Expected EssentialSubtotal ~ 90,933  Discretionary ~ 24,442  Total ~ 121,144';
PRINT '======================================================================';
EXEC dbo.usp_LivingExpenseEngine
    @Salary        = 200000,
    @Family        = 'Couple+3+',
    @Emirate       = 'Dubai',
    @Housing       = 'Rented',
    @IncomeBand    = '150K+',
    @Nationality   = 'Expat',
    @Region        = 'Western',
    @KidsUAE       = 2,
    @DepAbroad     = 2,
    @SpouseIncome  = 0;
GO

PRINT '';
PRINT '======================================================================';
PRINT 'Test 6: P7 — Expat couple, AD, Employer housing (rent = 0), 40,000';
PRINT 'Expected EssentialSubtotal ~ 5,816  Discretionary ~ 3,245  Total ~ 9,513';
PRINT '======================================================================';
EXEC dbo.usp_LivingExpenseEngine
    @Salary        = 40000,
    @Family        = 'Couple',
    @Emirate       = 'Abu Dhabi',
    @Housing       = 'Employer',
    @IncomeBand    = '30K-50K',
    @Nationality   = 'Expat',
    @Region        = 'Western',
    @KidsUAE       = 0,
    @DepAbroad     = 0,
    @SpouseIncome  = 0;
GO

PRINT '';
PRINT '======================================================================';
PRINT 'Test 7: Low-income Filipino single, Northern, sub-10K';
PRINT 'Expected EssentialSubtotal ~ 2,226  Discretionary ~ 575  Total ~ 2,940';
PRINT '======================================================================';
EXEC dbo.usp_LivingExpenseEngine
    @Salary        = 4500,
    @Family        = 'Single',
    @Emirate       = 'Northern',
    @Housing       = 'Rented',
    @IncomeBand    = '<10K',
    @Nationality   = 'Expat',
    @Region        = 'Filipino',
    @KidsUAE       = 0,
    @DepAbroad     = 2,
    @SpouseIncome  = 0;
GO

PRINT '';
PRINT '======================================================================';
PRINT 'Test 8: Working couple with spouse income';
PRINT 'Expected EssentialSubtotal ~ 13,321  Discretionary ~ 3,103  Total ~ 17,245';
PRINT '======================================================================';
EXEC dbo.usp_LivingExpenseEngine
    @Salary        = 25000,
    @Family        = 'Couple+1',
    @Emirate       = 'Dubai',
    @Housing       = 'Rented',
    @IncomeBand    = '20K-30K',
    @Nationality   = 'Expat',
    @Region        = 'South Asian',
    @KidsUAE       = 1,
    @DepAbroad     = 1,
    @SpouseIncome  = 15000;
GO
