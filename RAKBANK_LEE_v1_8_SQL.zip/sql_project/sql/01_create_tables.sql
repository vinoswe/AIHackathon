/* =================================================================
   RAKBANK Living Expense Engine v1.8 — Schema Creation
   ----------------------------------------------------------------
   Creates the 22 reference tables consumed by usp_LivingExpenseEngine.

   Each table corresponds to exactly one Excel file in /data; column
   names match the Excel headers, so SSMS Import Wizard / Azure Data
   Factory / BCP can load each file into its table without remapping.

   Dialect: T-SQL (Microsoft SQL Server 2016+). Adapt VARCHAR /
   DECIMAL types as needed for Oracle, PostgreSQL, etc.
   ================================================================= */

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

/* ---------- 1. Rent reference table -------------------------- */
IF OBJECT_ID('dbo.PARAM_RentTable', 'U') IS NOT NULL DROP TABLE dbo.PARAM_RentTable;
CREATE TABLE dbo.PARAM_RentTable (
    Emirate      VARCHAR(20)    NOT NULL,
    UnitType     VARCHAR(20)    NOT NULL,
    BudgetAmt    DECIMAL(18,2)  NOT NULL,
    MidAmt       DECIMAL(18,2)  NOT NULL,
    PremiumAmt   DECIMAL(18,2)  NOT NULL,
    CONSTRAINT PK_PARAM_RentTable PRIMARY KEY (Emirate, UnitType)
);

/* ---------- 2. Income band -> tier -------------------------- */
IF OBJECT_ID('dbo.PARAM_IncomeBandTier', 'U') IS NOT NULL DROP TABLE dbo.PARAM_IncomeBandTier;
CREATE TABLE dbo.PARAM_IncomeBandTier (
    IncomeBand   VARCHAR(20)    NOT NULL,
    Tier         VARCHAR(20)    NOT NULL,
    CONSTRAINT PK_PARAM_IncomeBandTier PRIMARY KEY (IncomeBand)
);

/* ---------- 3. Family -> unit type -------------------------- */
IF OBJECT_ID('dbo.PARAM_FamilyUnit', 'U') IS NOT NULL DROP TABLE dbo.PARAM_FamilyUnit;
CREATE TABLE dbo.PARAM_FamilyUnit (
    Family       VARCHAR(20)    NOT NULL,
    UnitType     VARCHAR(20)    NOT NULL,
    CONSTRAINT PK_PARAM_FamilyUnit PRIMARY KEY (Family)
);

/* ---------- 4. Rent-to-income ratio ------------------------- */
IF OBJECT_ID('dbo.PARAM_RentRatio', 'U') IS NOT NULL DROP TABLE dbo.PARAM_RentRatio;
CREATE TABLE dbo.PARAM_RentRatio (
    IncomeBand   VARCHAR(20)    NOT NULL,
    Family       VARCHAR(20)    NOT NULL,
    Ratio        DECIMAL(10,4)  NOT NULL,
    CONSTRAINT PK_PARAM_RentRatio PRIMARY KEY (IncomeBand, Family)
);

/* ---------- 5. Electricity / water -------------------------- */
IF OBJECT_ID('dbo.PARAM_ElectricityWater', 'U') IS NOT NULL DROP TABLE dbo.PARAM_ElectricityWater;
CREATE TABLE dbo.PARAM_ElectricityWater (
    Family         VARCHAR(20)   NOT NULL,
    ApartmentAmt   DECIMAL(18,2) NOT NULL,
    VillaAmt       DECIMAL(18,2) NOT NULL,
    CONSTRAINT PK_PARAM_ElectricityWater PRIMARY KEY (Family)
);

/* ---------- 6. Emirate utility factor ----------------------- */
IF OBJECT_ID('dbo.PARAM_EmirateUtilFactor', 'U') IS NOT NULL DROP TABLE dbo.PARAM_EmirateUtilFactor;
CREATE TABLE dbo.PARAM_EmirateUtilFactor (
    Emirate    VARCHAR(20)    NOT NULL,
    Factor     DECIMAL(10,4)  NOT NULL,
    CONSTRAINT PK_PARAM_EmirateUtilFactor PRIMARY KEY (Emirate)
);

/* ---------- 7. Telecom base --------------------------------- */
IF OBJECT_ID('dbo.PARAM_Telecom', 'U') IS NOT NULL DROP TABLE dbo.PARAM_Telecom;
CREATE TABLE dbo.PARAM_Telecom (
    Family       VARCHAR(20)    NOT NULL,
    BaseAmt      DECIMAL(18,2)  NOT NULL,
    CONSTRAINT PK_PARAM_Telecom PRIMARY KEY (Family)
);

/* ---------- 8. DEWA / housing fee % ------------------------- */
IF OBJECT_ID('dbo.PARAM_DewaFee', 'U') IS NOT NULL DROP TABLE dbo.PARAM_DewaFee;
CREATE TABLE dbo.PARAM_DewaFee (
    PropertyType  VARCHAR(20)   NOT NULL,
    FeePct        DECIMAL(10,4) NOT NULL,
    CONSTRAINT PK_PARAM_DewaFee PRIMARY KEY (PropertyType)
);

/* ---------- 9. Education base fees -------------------------- */
IF OBJECT_ID('dbo.PARAM_EducationBase', 'U') IS NOT NULL DROP TABLE dbo.PARAM_EducationBase;
CREATE TABLE dbo.PARAM_EducationBase (
    Emirate      VARCHAR(20)    NOT NULL,
    IncomeBand   VARCHAR(20)    NOT NULL,
    AnnualAED    DECIMAL(18,2)  NOT NULL,
    CONSTRAINT PK_PARAM_EducationBase PRIMARY KEY (Emirate, IncomeBand)
);

/* ---------- 10. Food % -------------------------------------- */
IF OBJECT_ID('dbo.PARAM_FoodPercent', 'U') IS NOT NULL DROP TABLE dbo.PARAM_FoodPercent;
CREATE TABLE dbo.PARAM_FoodPercent (
    Family       VARCHAR(20)    NOT NULL,
    IncomeBand   VARCHAR(20)    NOT NULL,
    Pct          DECIMAL(10,4)  NOT NULL,
    CONSTRAINT PK_PARAM_FoodPercent PRIMARY KEY (Family, IncomeBand)
);

/* ---------- 11. Transport % --------------------------------- */
IF OBJECT_ID('dbo.PARAM_TransportPercent', 'U') IS NOT NULL DROP TABLE dbo.PARAM_TransportPercent;
CREATE TABLE dbo.PARAM_TransportPercent (
    Family       VARCHAR(20)    NOT NULL,
    IncomeBand   VARCHAR(20)    NOT NULL,
    Pct          DECIMAL(10,4)  NOT NULL,
    CONSTRAINT PK_PARAM_TransportPercent PRIMARY KEY (Family, IncomeBand)
);

/* ---------- 12. Healthcare % -------------------------------- */
IF OBJECT_ID('dbo.PARAM_HealthcarePercent', 'U') IS NOT NULL DROP TABLE dbo.PARAM_HealthcarePercent;
CREATE TABLE dbo.PARAM_HealthcarePercent (
    Family       VARCHAR(20)    NOT NULL,
    IncomeBand   VARCHAR(20)    NOT NULL,
    Pct          DECIMAL(10,4)  NOT NULL,
    CONSTRAINT PK_PARAM_HealthcarePercent PRIMARY KEY (Family, IncomeBand)
);

/* ---------- 13. Domestic % ---------------------------------- */
IF OBJECT_ID('dbo.PARAM_DomesticPercent', 'U') IS NOT NULL DROP TABLE dbo.PARAM_DomesticPercent;
CREATE TABLE dbo.PARAM_DomesticPercent (
    Family       VARCHAR(20)    NOT NULL,
    IncomeBand   VARCHAR(20)    NOT NULL,
    Pct          DECIMAL(10,4)  NOT NULL,
    CONSTRAINT PK_PARAM_DomesticPercent PRIMARY KEY (Family, IncomeBand)
);

/* ---------- 14. Family-support % ---------------------------- */
IF OBJECT_ID('dbo.PARAM_FamilySupportPercent', 'U') IS NOT NULL DROP TABLE dbo.PARAM_FamilySupportPercent;
CREATE TABLE dbo.PARAM_FamilySupportPercent (
    Family       VARCHAR(20)    NOT NULL,
    IncomeBand   VARCHAR(20)    NOT NULL,
    Pct          DECIMAL(10,4)  NOT NULL,
    CONSTRAINT PK_PARAM_FamilySupportPercent PRIMARY KEY (Family, IncomeBand)
);

/* ---------- 15. Lifestyle % --------------------------------- */
IF OBJECT_ID('dbo.PARAM_LifestylePercent', 'U') IS NOT NULL DROP TABLE dbo.PARAM_LifestylePercent;
CREATE TABLE dbo.PARAM_LifestylePercent (
    Family       VARCHAR(20)    NOT NULL,
    IncomeBand   VARCHAR(20)    NOT NULL,
    Pct          DECIMAL(10,4)  NOT NULL,
    CONSTRAINT PK_PARAM_LifestylePercent PRIMARY KEY (Family, IncomeBand)
);

/* ---------- 16. Floor / ceiling per category × family ------- */
IF OBJECT_ID('dbo.PARAM_FloorCeiling', 'U') IS NOT NULL DROP TABLE dbo.PARAM_FloorCeiling;
CREATE TABLE dbo.PARAM_FloorCeiling (
    Category     VARCHAR(30)    NOT NULL,
    Family       VARCHAR(20)    NOT NULL,
    FloorAmt     DECIMAL(18,2)  NOT NULL,
    CeilAmt      DECIMAL(18,2)  NOT NULL,
    CONSTRAINT PK_PARAM_FloorCeiling PRIMARY KEY (Category, Family)
);

/* ---------- 17. Insurance ----------------------------------- */
IF OBJECT_ID('dbo.PARAM_Insurance', 'U') IS NOT NULL DROP TABLE dbo.PARAM_Insurance;
CREATE TABLE dbo.PARAM_Insurance (
    IncomeBand   VARCHAR(20)    NOT NULL,
    BaseAmt      DECIMAL(18,2)  NOT NULL,
    CONSTRAINT PK_PARAM_Insurance PRIMARY KEY (IncomeBand)
);

/* ---------- 18. Housing factor ------------------------------ */
IF OBJECT_ID('dbo.PARAM_HousingFactor', 'U') IS NOT NULL DROP TABLE dbo.PARAM_HousingFactor;
CREATE TABLE dbo.PARAM_HousingFactor (
    HousingType  VARCHAR(20)    NOT NULL,
    Factor       DECIMAL(10,4)  NOT NULL,
    CONSTRAINT PK_PARAM_HousingFactor PRIMARY KEY (HousingType)
);

/* ---------- 19. Region multipliers (4 dims) ----------------- */
IF OBJECT_ID('dbo.PARAM_RegionMultiplier', 'U') IS NOT NULL DROP TABLE dbo.PARAM_RegionMultiplier;
CREATE TABLE dbo.PARAM_RegionMultiplier (
    Region          VARCHAR(50)    NOT NULL,
    FoodMult        DECIMAL(10,4)  NOT NULL,
    FamSupMult      DECIMAL(10,4)  NOT NULL,
    LifestyleMult   DECIMAL(10,4)  NOT NULL,
    DomesticMult    DECIMAL(10,4)  NOT NULL,
    CONSTRAINT PK_PARAM_RegionMultiplier PRIMARY KEY (Region)
);

/* ---------- 20. Education multiplier (region × band) -------- */
IF OBJECT_ID('dbo.PARAM_EducationMultiplier', 'U') IS NOT NULL DROP TABLE dbo.PARAM_EducationMultiplier;
CREATE TABLE dbo.PARAM_EducationMultiplier (
    Region       VARCHAR(50)    NOT NULL,
    IncomeBand   VARCHAR(20)    NOT NULL,
    Multiplier   DECIMAL(10,4)  NOT NULL,
    CONSTRAINT PK_PARAM_EducationMultiplier PRIMARY KEY (Region, IncomeBand)
);

/* ---------- 21. Telecom tier multiplier --------------------- */
IF OBJECT_ID('dbo.PARAM_TierTelecomMult', 'U') IS NOT NULL DROP TABLE dbo.PARAM_TierTelecomMult;
CREATE TABLE dbo.PARAM_TierTelecomMult (
    Tier         VARCHAR(20)    NOT NULL,
    Multiplier   DECIMAL(10,4)  NOT NULL,
    CONSTRAINT PK_PARAM_TierTelecomMult PRIMARY KEY (Tier)
);

/* ---------- 22. Scalars ------------------------------------- */
IF OBJECT_ID('dbo.PARAM_Scalars', 'U') IS NOT NULL DROP TABLE dbo.PARAM_Scalars;
CREATE TABLE dbo.PARAM_Scalars (
    ParameterName  VARCHAR(50)    NOT NULL,
    ScalarValue    DECIMAL(18,4)  NOT NULL,
    Description    VARCHAR(255)   NULL,
    CONSTRAINT PK_PARAM_Scalars PRIMARY KEY (ParameterName)
);

GO

/* =================================================================
   End of schema. After running this script, load each Excel file
   into the corresponding table using SSMS Import Wizard, Azure
   Data Factory, BCP, or SSIS. Excel file names match table names
   1:1 so no field mapping is required.
   ================================================================= */
