# RAKBANK Living Expense Engine v1.8 — SQL Project

Stored-procedure implementation of the Living Expense Engine. Returns
exactly three values per applicant:

| Output | Meaning |
|---|---|
| `EssentialSubtotal` | Rent + Food + Transport + Utilities + Education + Healthcare |
| `DiscretionarySubtotal` | Insurance + Family Support + Lifestyle + Domestic Help |
| `TotalMonthlyExpenseFloor` | (Essential + Discretionary) × (1 + Buffer%) |

No other columns are produced.

## Project layout

```
.
├── README.md
├── data/                              ← 22 Excel files (one per SQL table)
│   ├── PARAM_RentTable.xlsx
│   ├── PARAM_IncomeBandTier.xlsx
│   ├── PARAM_FamilyUnit.xlsx
│   ├── PARAM_RentRatio.xlsx
│   ├── PARAM_ElectricityWater.xlsx
│   ├── PARAM_EmirateUtilFactor.xlsx
│   ├── PARAM_Telecom.xlsx
│   ├── PARAM_DewaFee.xlsx
│   ├── PARAM_EducationBase.xlsx
│   ├── PARAM_FoodPercent.xlsx
│   ├── PARAM_TransportPercent.xlsx
│   ├── PARAM_HealthcarePercent.xlsx
│   ├── PARAM_DomesticPercent.xlsx
│   ├── PARAM_FamilySupportPercent.xlsx
│   ├── PARAM_LifestylePercent.xlsx
│   ├── PARAM_FloorCeiling.xlsx
│   ├── PARAM_Insurance.xlsx
│   ├── PARAM_HousingFactor.xlsx
│   ├── PARAM_RegionMultiplier.xlsx
│   ├── PARAM_EducationMultiplier.xlsx
│   ├── PARAM_TierTelecomMult.xlsx
│   └── PARAM_Scalars.xlsx
├── sql/
│   ├── 01_create_tables.sql           ← DDL for all 22 tables
│   ├── 02_create_procedure.sql        ← usp_LivingExpenseEngine
│   └── 03_test_cases.sql              ← Eight canonical test calls
└── test/
    └── verify_sql_logic.py            ← Python parity harness (Pandas)
```

## Deployment

The Excel file name **is** the SQL table name. Loading each file into its
table requires no field mapping.

### Step 1 — Create the schema

In SQL Server Management Studio (SSMS), connect to the target database and run:

```sql
sqlcmd -S <server> -d <database> -i sql/01_create_tables.sql
```

Or open the script in SSMS and execute it. This creates 22 empty tables with
correct keys and data types.

### Step 2 — Load each Excel into its table

Use any of the following:

- **SSMS Import Wizard** (Tasks → Import Data → Excel source → SQL Server destination).
  Source tab name will be `Sheet1`; destination table name is the filename without
  extension. Confirm "Use existing table" (do not let the wizard recreate it).
- **Azure Data Factory / SSIS** — point a Copy Activity at each Excel file; set
  the destination table name = source filename stem.
- **BCP / OPENROWSET** — see the snippet in `sql/01_create_tables.sql` comments.
- **Python (pandas + pyodbc)** for automated reloads:

  ```python
  import pandas as pd, pyodbc
  conn = pyodbc.connect("...")
  for fn in os.listdir("data"):
      tbl = fn.replace(".xlsx","")
      df = pd.read_excel(f"data/{fn}")
      df.to_sql(tbl, conn, if_exists="append", index=False)
  ```

### Step 3 — Create the stored procedure

```sql
sqlcmd -S <server> -d <database> -i sql/02_create_procedure.sql
```

### Step 4 — Run the test cases

```sql
sqlcmd -S <server> -d <database> -i sql/03_test_cases.sql
```

The expected output for each test profile is printed above the call.

### Step 5 (optional) — Python verification

To verify the parameter tables contain everything the SP needs without
running SQL Server, run:

```bash
cd test
pip install pandas openpyxl
python3 verify_sql_logic.py
```

This re-implements the SP logic in Python over the same Excel data and prints
the three output values for each test profile. Any missing parameter row will
raise `KeyError`.

## Stored procedure interface

```sql
EXEC dbo.usp_LivingExpenseEngine
    @Salary        = <decimal, monthly AED>,
    @Family        = <'Single' | 'Couple' | 'Couple+1' | 'Couple+2' | 'Couple+3+'>,
    @Emirate       = <'Dubai' | 'Abu Dhabi' | 'Sharjah-Ajman' | 'Northern'>,
    @Housing       = <'Rented' | 'Owned-mortgage' | 'Owned-free' | 'Employer'>,
    @IncomeBand    = <'<10K' | '10K-15K' | '15K-20K' | '20K-30K' |
                       '30K-50K' | '50K-80K' | '80K-150K' | '150K+'>,
    @Nationality   = <'UAE National' | 'Expat'>,
    @Region        = <one of 13 cultural-region labels — see PARAM_RegionMultiplier>,
    @KidsUAE       = <int, default 0>,
    @DepAbroad     = <int, default 0>,
    @SpouseIncome  = <decimal, default 0>;
```

Returns one row with three columns:

```
EssentialSubtotal | DiscretionarySubtotal | TotalMonthlyExpenseFloor
```

## How the SP works (computation flow)

1. **Scalars** — `BufferPct`, `CalEssential`, `CalDiscretionary`,
   `SpouseInclusion`, `AbsRentFloor`, `ZeroSalaryFallback` are read from
   `PARAM_Scalars`.
2. **HH income** = primary salary + 0.5 × spouse income (uses 7,000 fallback
   if primary salary is zero).
3. **Property type** = Villa if (UAE National with kids) OR (Couple+3+);
   else Apartment.
4. **Essential lines:**
   - Rent = HH × ratio × cal_essential, bounded by `[AbsRentFloor,
     premium-tier rent]`, then × housing factor.
   - Food = HH × food% × region food multiplier × cal_essential, floor/ceiling
     applied.
   - Transport = HH × transport% × cal_essential, floor/ceiling applied.
   - Utilities = elec/water (by family × property × emirate factor) +
     telecom (by family × tier multiplier) + rent × DEWA fee%.
   - Education = (annual base × education multiplier ÷ 12) × kids in UAE,
     zero if no kids in UAE.
   - Healthcare = HH × health% × cal_essential, floor/ceiling applied.
5. **Discretionary lines:**
   - Insurance = base × cal_discretionary.
   - Family Support = primary salary × famsup% × region famsup multiplier ×
     cal_discretionary, floor/ceiling applied, then × (1 + 0.5 × dependents
     abroad), final cap at 1.5 × ceiling.
   - Lifestyle and Domestic = HH × pct × region multiplier × cal_discretionary,
     floor/ceiling applied.
6. **Total Monthly Expense Floor** = (Essential + Discretionary) × (1 + Buffer%).

## Tables — quick reference

| # | Table | Rows | Purpose |
|---|---|---|---|
| 1 | `PARAM_RentTable` | 16 | Annual rent benchmark by emirate × unit type × tier |
| 2 | `PARAM_IncomeBandTier` | 8 | Maps income band to rent/telecom tier |
| 3 | `PARAM_FamilyUnit` | 5 | Maps family composition to housing unit type |
| 4 | `PARAM_RentRatio` | 40 | Rent-to-income ratio by band × family |
| 5 | `PARAM_ElectricityWater` | 5 | Elec/water by family for apartment vs villa |
| 6 | `PARAM_EmirateUtilFactor` | 4 | Utility cost factor per emirate |
| 7 | `PARAM_Telecom` | 5 | Base telecom by family size |
| 8 | `PARAM_DewaFee` | 2 | Housing-fee % of rent (apartment vs villa) |
| 9 | `PARAM_EducationBase` | 32 | Annual fee anchor by emirate × band |
| 10 | `PARAM_FoodPercent` | 40 | Food expense % by family × band |
| 11 | `PARAM_TransportPercent` | 40 | Transport % by family × band |
| 12 | `PARAM_HealthcarePercent` | 40 | Healthcare % by family × band |
| 13 | `PARAM_DomesticPercent` | 40 | Domestic help % by family × band |
| 14 | `PARAM_FamilySupportPercent` | 40 | Remittance % by family × band |
| 15 | `PARAM_LifestylePercent` | 40 | Lifestyle % by family × band |
| 16 | `PARAM_FloorCeiling` | 30 | Min/max bounds per category × family |
| 17 | `PARAM_Insurance` | 8 | Insurance base by band |
| 18 | `PARAM_HousingFactor` | 4 | Housing-type adjustment on rent line |
| 19 | `PARAM_RegionMultiplier` | 13 | Food/famsup/lifestyle/domestic by region |
| 20 | `PARAM_EducationMultiplier` | 104 | Education multiplier by region × band |
| 21 | `PARAM_TierTelecomMult` | 3 | Telecom tier multiplier (Budget/Mid/Premium) |
| 22 | `PARAM_Scalars` | 6 | Six scalar parameters |

Total: 22 tables, 525 parameter rows.

## Maintenance

To update a parameter:

1. Edit the relevant Excel file in `data/`.
2. Truncate the corresponding SQL table and reload from the updated Excel.
3. Re-run `test/verify_sql_logic.py` to confirm the change has the expected
   effect on the canonical test profiles.
4. Re-run `sql/03_test_cases.sql` to confirm SQL parity.
5. Log the change in your model governance log per the bank's MRM policy.

The procedure itself does not need to be recompiled because all values are
table-driven.

## Notes for SQL platforms other than SQL Server

The SQL is straightforward `SELECT ... WHERE` against single-row lookups
and basic CASE/IF logic; it ports to other dialects with minimal change:

- **Oracle PL/SQL** — change `VARCHAR` to `VARCHAR2`, `GO` to `/`, `DECLARE
  @x` to `x` in a `DECLARE` block; `SET @x = ...` becomes `x := ...`.
- **PostgreSQL** — wrap in `CREATE OR REPLACE FUNCTION ... RETURNS TABLE(...)
  LANGUAGE plpgsql AS $$ ... $$;` and replace `@` with `_` in variable names.
- **Teradata** — supported as a stored procedure with similar syntax;
  `DECIMAL(18,2)` and `VARCHAR` are identical.

The parameter tables themselves load identically on any platform that
supports Excel ingestion.
